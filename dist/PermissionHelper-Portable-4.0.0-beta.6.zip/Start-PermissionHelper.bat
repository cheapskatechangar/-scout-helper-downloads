@echo off
setlocal DisableDelayedExpansion
set "SCOUT_HELPER_HOST=%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe"
set "SCOUT_HELPER_SCRIPT=%~dp0PermissionHelper.Portable.ps1"
if not exist "%SCOUT_HELPER_HOST%" (
    echo Windows PowerShell 5.1 is required.
    pause
    exit /b 1
)
if not exist "%SCOUT_HELPER_SCRIPT%" (
    echo Extract BOTH files from the ZIP into the same folder, then try again.
    pause
    exit /b 1
)
start "" "%SCOUT_HELPER_HOST%" -NoLogo -NoProfile -STA -WindowStyle Hidden -ExecutionPolicy Bypass -Command "try { & $env:SCOUT_HELPER_SCRIPT } catch { Add-Type -AssemblyName System.Windows.Forms; [System.Windows.Forms.MessageBox]::Show($_.Exception.Message, 'Permission Helper could not start') | Out-Null; exit 1 }"
exit /b

